import React from "react";

function App() {
  return (
    <div>
      <h1>FlowCaddy</h1>
      <p>Welcome to the beta version of the FlowCaddy hydronics calculator.</p>
    </div>
  );
}

export default App;
